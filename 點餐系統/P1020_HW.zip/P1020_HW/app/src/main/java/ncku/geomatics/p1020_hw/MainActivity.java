package ncku.geomatics.p1020_hw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
implements RadioGroup.OnCheckedChangeListener,CompoundButton.OnCheckedChangeListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioGroup rg1 = findViewById(R.id.rgMm);
        RadioGroup rg2 = findViewById(R.id.rgDr);
        RadioGroup rg3 = findViewById(R.id.rgSu);
        RadioGroup rg4 = findViewById(R.id.rgIc);

        rg1.setOnCheckedChangeListener(this);
        rg2.setOnCheckedChangeListener(this);
        rg3.setOnCheckedChangeListener(this);
        rg4.setOnCheckedChangeListener(this);

        CheckBox cb1=findViewById(R.id.cbF);
        CheckBox cb2=findViewById(R.id.cbI);

        cb1.setOnCheckedChangeListener(this);
        cb2.setOnCheckedChangeListener(this);
    }

    void show(){
        int sum=0;
        int m_c=0; // main_cost
        int d_c=0;
        int s_c=0;

        String str = "Ur main meal is ";
        String main="";
        String drink="";
        String sugar="";
        String ice="";
        String side="";


        TextView tv = findViewById(R.id.tv);
        RadioGroup rg1 = findViewById(R.id.rgMm);
        RadioGroup rg2 = findViewById(R.id.rgDr);
        RadioGroup rg3 = findViewById(R.id.rgSu);
        RadioGroup rg4 = findViewById(R.id.rgIc);

        CheckBox cb1=findViewById(R.id.cbF);
        CheckBox cb2=findViewById(R.id.cbI);

        ImageView iv1=findViewById(R.id.p1);
        ImageView iv2=findViewById(R.id.p2);
        ImageView iv3=findViewById(R.id.p3);
        ImageView iv4=findViewById(R.id.p4);
        ImageView iv5=findViewById(R.id.p5);
        ImageView iv6=findViewById(R.id.p6);

        if (rg1.getCheckedRadioButtonId()==R.id.rbH){
            main="Hamburger.\n\n";
            m_c=40;
            iv1.setVisibility(View.VISIBLE);
            iv2.setVisibility(View.GONE);
        }
        else if (rg1.getCheckedRadioButtonId()==R.id.rbC){
            main+="Chicken.\n\n";
            tv.setText(str);
            m_c=50;
            iv2.setVisibility(View.VISIBLE);
            iv1.setVisibility(View.GONE);
        }

        if (rg2.getCheckedRadioButtonId()==R.id.rbB){
            drink="Ur drink is Black tea.\n";
            d_c=20;
            iv3.setVisibility(View.VISIBLE);
            iv4.setVisibility(View.GONE);
        }
        else if (rg2.getCheckedRadioButtonId()==R.id.rbCo){
            drink="Ur drink is Coffee.\n";
            d_c=30;
            iv4.setVisibility(View.VISIBLE);
            iv3.setVisibility(View.GONE);
        }

        if (rg3.getCheckedRadioButtonId()==R.id.rbHS){
            sugar=", which is Half sugar and";

        }
        else if (rg3.getCheckedRadioButtonId()==R.id.rbNS){
            drink+=", which is No sugar and";
        }

        if (rg4.getCheckedRadioButtonId()==R.id.rbLI){
            ice=" Less Ice\n\n";
        }
        else if (rg4.getCheckedRadioButtonId()==R.id.rbNI){
            ice=" No Ice\n\n";
        }

        if (cb1.isChecked()){
            side+="U still have side meal:\n"+"Fried Chips\n\n";
            s_c+=20;
            iv5.setVisibility(View.VISIBLE);
        }else{
            iv5.setVisibility(View.GONE);
        }

        if (cb2.isChecked()){
            side+="U still have side meal:\n"+"Fried Chips\n\n";
            s_c+=30;
            iv6.setVisibility(View.VISIBLE);
        }else{
            iv6.setVisibility(View.GONE);
        }

        sum=m_c+d_c+s_c;
        str+=main+drink+sugar+ice+side+"U should pay $";
        tv.setText(str+String.format("%d",sum));

    }

    public void Onclick(View V){
        show();
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        show();
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        show();
    }
}