package ncku.geomatics.p1124_2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    SensorManager sm;
    Sensor sr;
    int grade = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        sr = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        sm.registerListener(this,sr,SensorManager.SENSOR_DELAY_NORMAL);


        ImageView iv = findViewById(R.id.imageView);
        ImageView star = findViewById(R.id.imageView2);

        // 取得 泡泡的布局參數
        ConstraintLayout.LayoutParams pr = (ConstraintLayout.LayoutParams) iv.getLayoutParams();
        ConstraintLayout.LayoutParams star_po = (ConstraintLayout.LayoutParams) star.getLayoutParams();
        pr.horizontalBias = (float) 0.5;
        pr.verticalBias = (float) 0.5;
        iv.setLayoutParams(pr);

        star_po.horizontalBias = (float) 0.8;
        star_po.verticalBias = (float) 0.2;
        star.setLayoutParams(star_po);


        AlertDialog.Builder bdr = new AlertDialog.Builder(this);

    }

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {

            ImageView iv = findViewById(R.id.imageView);
            ImageView star = findViewById(R.id.imageView2);
            // 取得 泡泡的布局參數
            ConstraintLayout.LayoutParams pr = (ConstraintLayout.LayoutParams) iv.getLayoutParams();
            ConstraintLayout.LayoutParams star_po = (ConstraintLayout.LayoutParams) star.getLayoutParams();

            // 根據 X Y 去調整 horizontalBias 及 VerticalBias
            float X = sensorEvent.values[0];
            float Y = sensorEvent.values[1];

            pr.horizontalBias = (X+9.8f)/19.6f;
            pr.verticalBias = (9.8f-Y)/19.6f;

            iv.setLayoutParams(pr);

            double x_bias=0.0;
            double y_bias=0.0;



            TextView tv;
            tv = findViewById(R.id.textView);


            x_bias = Math.abs(pr.horizontalBias-star_po.horizontalBias);
            y_bias = Math.abs(pr.verticalBias - star_po.verticalBias);



            if((x_bias < 0.04 ) && (y_bias < 0.04 )){
                grade+=1;

                tv.setText(String.format("Ur grade is %2d",grade));
                Toast.makeText(this,"+1 !",Toast.LENGTH_SHORT).show();

                Random r = new Random();
                double pos_x = 0.2 + (0.8 - 0.2) * r.nextDouble();
                double pos_y = 0.2 + (0.8 - 0.2) * r.nextDouble();

                if(pos_x > 0.8)
                    pos_x = 0.8;
                if(pos_y > 0.8)
                    pos_y = 0.8;



                star_po.horizontalBias = (float) pos_x;
                star_po.verticalBias = (float) pos_y;
                star.setLayoutParams(star_po);

                if(grade>=3){
                    AlertDialog.Builder bdr = new AlertDialog.Builder(this);
                    bdr.setMessage("U have broken the record !");
                    bdr.setTitle("Amazing!!!");
                    bdr.setPositiveButton("Keep Playing",null);
                    bdr.setCancelable(true);
                    bdr.show();
                }
            }



        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }

}