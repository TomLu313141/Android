package ncku.geomatics.p1201;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener, OnMapReadyCallback,
        SensorEventListener{

    SensorManager sm;
    Sensor sr1;
    Sensor sr2;

    float[] aValue = new float[3];
    float[] mValue = new float[3];

    float[] rotation = new float[9];
    float[] degree = new float[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);

        sr1 = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sm.registerListener(this,sr1,SensorManager.SENSOR_DELAY_NORMAL);

        sr2 = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        sm.registerListener(this,sr2,SensorManager.SENSOR_DELAY_NORMAL);



        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions

            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.ACCESS_FINE_LOCATION},200);
            // 200 為授權碼


            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        lm.requestLocationUpdates("gps", 3000, 5, this);

        SupportMapFragment smf = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        smf.getMapAsync(this);

    }

    double lat,lng,alt;
    EditText des;

    @Override
    public void onLocationChanged(@NonNull Location location) {

        lat = location.getLatitude();
        lng = location.getLongitude();


        updateCameraBearing(mMap, location.getBearing());

    }
    private void updateCameraBearing(GoogleMap googleMap, float bearing) {
        if ( googleMap == null) return;
        CameraPosition camPos = CameraPosition
                .builder(
                        googleMap.getCameraPosition() // current Camera
                )
                .bearing(bearing)
                .build();
        googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(camPos));
    }


    public void Onclick(View V){

        Geocoder geo = new Geocoder(this, Locale.getDefault());

        des = findViewById(R.id.et);
        String str = des.getText().toString();


        try {
            // 先給緯度，再給經度
            List<Address>  la = geo.getFromLocation(lat,lng,1);

            la = geo.getFromLocationName(str,1);


            if(la!=null && la.size()>0){

                Address a = la.get(0);
                String s="";

                double lat2 = a.getLatitude();
                double lng2 = a.getLongitude();


                for(int i=0;i<=a.getMaxAddressLineIndex();i++){
                    s += a.getAddressLine(i);
                }

//                s += "\n"+lat2;
//                s += "\n"+lng2;

                ((TextView)findViewById(R.id.tvshow)).setText(s);

                if(mMap!=null) {
                    LatLng des_loc = new LatLng(lat2, lng2);
                    mMap.addMarker(new MarkerOptions().position(des_loc).title(str));
                }

                double  distance=0;
                distance = GetDistance(23.000614, 120.217794, lat2,lng2);


                ((TextView)findViewById(R.id.tv_dis)).setText(distance+" (m)");

            }


        }catch (Exception e){
        }

    }

    private static double rad(double d) {
        return d * Math.PI / 180.0;
    }

    public static double GetDistance(double lat1, double lng1, double lat2, double lng2) {
        double EARTH_RADIUS = 6378137;
        double radLat1 = rad(lat1);
        double radLat2 = rad(lat2);
        double a = radLat1 - radLat2;
        double b = rad(lng1) - rad(lng2);
        double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2)
                + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
        s = s * EARTH_RADIUS;
        s = Math.round(s * 10000) / 10000;
        return s;
    }








    GoogleMap mMap = null;

    @Override
   public void onMapReady(GoogleMap googleMap) {



        mMap = googleMap;

        LatLng  ncku = new LatLng(23.000614, 120.217794);
        mMap.addMarker(new MarkerOptions().position(ncku).title("NCKU"));
        mMap.moveCamera(CameraUpdateFactory.zoomTo(15)); // 數字越大，越精細

        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);

        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(ncku)
                .zoom(13)                   // Sets the zoom
                .bearing(angle+90)                // Sets the orientation of the camera to east
                .tilt(30)                   // Sets the tilt of the camera to 30 degrees
                .build();                   // Creates a CameraPosition from the builder
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));


    }


    float angle;

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
            mValue[0]=event.values[0];
            mValue[1]=event.values[1];
            mValue[2]=event.values[2];
        }else if(event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
            mValue[0]=event.values[0];
            mValue[1]=event.values[1];
            mValue[2]=event.values[2];
        }

        SensorManager.getRotationMatrix(rotation,null,aValue,mValue);
        SensorManager.getOrientation(rotation,degree);
        angle = (float) Math.toDegrees(degree[0]);

        angle = -angle;

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

}