package ncku.geomatics.p1117_hw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void Cancel(View V){
        setResult(RESULT_CANCELED);
        finish();
    }
    public void Enter(View V){
        Intent it2 = new Intent();

        String s= ((EditText)findViewById(R.id.etTxt)).getText().toString();
        it2.putExtra("店名",s);

        setResult(RESULT_OK,it2);
        finish();

    }
}