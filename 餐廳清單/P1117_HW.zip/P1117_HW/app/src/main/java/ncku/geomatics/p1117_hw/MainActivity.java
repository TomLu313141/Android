package ncku.geomatics.p1117_hw;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener,
        AdapterView.OnItemLongClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = findViewById(R.id.lv);
        lv.setOnItemClickListener(this);
        lv.setOnItemLongClickListener(this);

        rest = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, choice);

        choice.add("新增店家");
        lv.setAdapter(rest);

        tos=Toast.makeText(this,"",Toast.LENGTH_SHORT);
    }

    ListView lv;
    ArrayList<String> choice = new ArrayList<>();
    ArrayAdapter<String> rest;
    int length;
    Toast tos;

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        length = choice.size();

        // 點到 新增店家
        if(i == length-1){
            Intent it = new Intent();
            it.setClass(this,MainActivity2.class);
            startActivityForResult(it,101);
        }else{

            Intent it = new Intent();
            it.setAction(Intent.ACTION_VIEW);
            Uri uri = Uri.parse("https://www.google.com/"); // String to Uri
            it.setData(uri);
            startActivity(it);

        }


    }

    // 長按清除listView 之 element
    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

        length = choice.size();

        if(i< (length-1) ) {
            choice.remove(i);
            lv.setAdapter(rest);
        }

        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if( requestCode == 101 && resultCode== RESULT_OK ){


            String s = data.getStringExtra("店名");
            choice.remove("新增店家");
            choice.add(s);
            choice.add("新增店家");

            rest = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,choice);
            lv.setAdapter(rest);

        }

    }

    public void choose(View V){
        length = choice.size();

        if(length>=2) {
            Random rand = new Random();
            int no = rand.nextInt((length - 1));

            tos.setText(choice.get(no));
            tos.show();
        }else{
            tos.setText("U should add restaurant");
            tos.show();
        }


    }

}