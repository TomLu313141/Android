package ncku.geomatics.p1103_hw;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity
implements View.OnClickListener,DatePickerDialog.OnDateSetListener
,TimePickerDialog.OnTimeSetListener,DialogInterface.OnClickListener {

    Toast tos;
    String str;
    AlertDialog.Builder b;
    ImageView iv1,iv2,iv3;
    int flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv1 = findViewById(R.id.morning);
        iv2 = findViewById(R.id.noon);
        iv3 = findViewById(R.id.night);
        iv1.setVisibility(View.GONE);
        iv2.setVisibility(View.GONE);
        iv3.setVisibility(View.GONE);
        tos=Toast.makeText(this,"",Toast.LENGTH_LONG);
    }

    // click button
    @Override
    public void onClick(View view) {
        flag=0;

        if (view.getId()==R.id.btn){

            DatePickerDialog dpd = new DatePickerDialog(this,this::onDateSet,2021,10,3);
            // show 在哪，按確定後要幹嘛，預設 年，預設 月份(從0開始!!!)，預設日期
            dpd.show();
            }
        }



    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
            str="The Day u choose is:\n"+"year: "+i+" month: "+ (i1+1)+" day: "+i2;
            new TimePickerDialog(this,this::onTimeSet,15,55,true).show();
    }

    @Override
    public void onTimeSet(TimePicker timePicker, int i, int i1) {
            iv1 = findViewById(R.id.morning);
            iv2 = findViewById(R.id.noon);
            iv3 = findViewById(R.id.night);

            AlertDialog.Builder b=new AlertDialog.Builder(this);
            b.setTitle("Ticket Info");

            int hour=i;
            String time="";
            if(hour>=13){
                hour-=12;
                hour+=1;
                time = "pm";}
            else
                hour+=1;
                time = "am";


            if(i<6){
                b.setMessage("The time u choose doesn't have the ticket!");
                b.setPositiveButton("Enter", this);
                b.setNegativeButton("Cancel", this);
                b.show();
                flag=1;
            }
            else {
                if (i >= 6 && i < 12)
                    iv1.setVisibility(View.VISIBLE);
                if (i >= 12 && i <= 18)
                    iv2.setVisibility(View.VISIBLE);
                if (i > 18)
                    iv3.setVisibility(View.VISIBLE);

                str += "\n\nThe time u choose is: " + String.format("%02d:%02d", i, i1);
                str += "\n\nThe ticket u booked will departure at \n" + String.format("%d o'clock ", hour) + time;


                b.setMessage(str);
                b.setPositiveButton("Enter", this);
                b.setNegativeButton("Cancel", this);
                b.show();
            }

    }

    // click Alert
    @Override
    public void onClick(DialogInterface dialogInterface, int i) {
        // i -> 哪顆 btn
        if (flag == 1) {
            String su = "There is no ticket!";
            Snackbar.make(findViewById(R.id.root), su, Snackbar.LENGTH_LONG).show();
        } else {

            if (i == DialogInterface.BUTTON_POSITIVE) {
                String su = "Book Ticket Success";
                Snackbar.make(findViewById(R.id.root), su, Snackbar.LENGTH_LONG).show();

            } else if (i == DialogInterface.BUTTON_NEGATIVE) {
                tos.setText("Cancel Book ticket");
                tos.show();
            }
        }
    }
}