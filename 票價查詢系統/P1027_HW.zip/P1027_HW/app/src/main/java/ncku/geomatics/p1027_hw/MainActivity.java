package ncku.geomatics.p1027_hw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import java.lang.Math;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
implements RadioGroup.OnCheckedChangeListener,
        AdapterView.OnItemSelectedListener,
        AdapterView.OnItemClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioGroup rg1 = findViewById(R.id.rg);
        rg1.setOnCheckedChangeListener(this);

        Spinner s = findViewById(R.id.sp);
        s.setOnItemSelectedListener(this);

        ListView lv = findViewById(R.id.lv);
        lv.setOnItemClickListener(this);
    }

    int flag = 0;
    int dep = 0, des = 0;

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        show_spinner();
    }

    int show_spinner() {
        TextView txv2 = findViewById(R.id.tvShow2);
        TextView txv3 = findViewById(R.id.tvShow3);

        txv2.setText("Destination");
        txv3.setText("Price");

        RadioGroup rg1 = findViewById(R.id.rg);

        ArrayList<String> choice = new ArrayList<>();
        choice.add("Taipei");
        choice.add("Taoyuan");
        choice.add("Hsinchu");
        choice.add("Taichung");
        choice.add("Chiayi");
        choice.add("Tainan");
        choice.add("Kaohsiung");

        ArrayAdapter<String> choice2 = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, choice);
        choice2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner s = findViewById(R.id.sp);

        // to North
        if (rg1.getCheckedRadioButtonId() == R.id.rbN) {
            choice.remove(0);
            s.setAdapter(choice2);
            flag = 0;

            // to South
        } else if (rg1.getCheckedRadioButtonId() == R.id.rbS) {
            choice.remove(6);
            s.setAdapter(choice2);
            flag = 1;
        }

        return flag;
    }

    // for spinner
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        TextView txv = findViewById(R.id.tvShow);
        TextView txv2 = findViewById(R.id.tvShow2);
        TextView txv3 = findViewById(R.id.tvShow3);

        txv2.setText("Destination");
        txv3.setText("Price");

        ArrayList<String> choice3 = new ArrayList<>();

        ArrayAdapter<String> choice4 = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, choice3);

        ListView lv = findViewById(R.id.lv);


        if (flag == 0) { // to North
            if (i == 0) { //  from Taoyuan
                dep = 1;
                txv.setText("Ur Departure is Taoyuan");
                choice3.add("Taipei");
                lv.setAdapter(choice4);
            }
            if (i == 1) {
                dep = 2;
                txv.setText("Ur Departure is Hsinchu");
                choice3.add("Taipei");
                choice3.add("Taoyuan");
                lv.setAdapter(choice4);
            }
            if (i == 2) {
                dep = 3;
                txv.setText("Ur Departure is Taichung");
                choice3.add("Taipei");
                choice3.add("Taoyuan");
                choice3.add("Hsinchu");
                lv.setAdapter(choice4);
            }
            if (i == 3) {
                dep = 4;
                txv.setText("Ur Departure is Chiayi");
                choice3.add("Taipei");
                choice3.add("Taoyuan");
                choice3.add("Hsinchu");
                choice3.add("Taichung");
                lv.setAdapter(choice4);
            }
            if (i == 4) {
                dep = 5;
                txv.setText("Ur Departure is Tainan");
                choice3.add("Taipei");
                choice3.add("Taoyuan");
                choice3.add("Hsinchu");
                choice3.add("Taichung");
                choice3.add("Chiayi");
                lv.setAdapter(choice4);
            }
            if (i == 5) {
                dep = 6;
                txv.setText("Ur Departure is Kaohsiung");
                choice3.add("Taipei");
                choice3.add("Taoyuan");
                choice3.add("Hsinchu");
                choice3.add("Taichung");
                choice3.add("Chiayi");
                choice3.add("Tainan");
                lv.setAdapter(choice4);
            }
        }
        if (flag == 1) {
            if (i == 0) { //  from Taipei
                dep = 0;
                txv.setText("Ur Departure is Taipei");
                choice3.add("Taoyuan");
                choice3.add("Hsinchu");
                choice3.add("Taichung");
                choice3.add("Chiayi");
                choice3.add("Tainan");
                choice3.add("Kaohsiung");
                lv.setAdapter(choice4);
            }
            if (i == 1) {
                dep = 1;
                txv.setText("Ur Departure is Taoyuan");
                choice3.add("Hsinchu");
                choice3.add("Taichung");
                choice3.add("Chiayi");
                choice3.add("Tainan");
                choice3.add("Kaohsiung");
                lv.setAdapter(choice4);
            }
            if (i == 2) {
                dep = 2;
                txv.setText("Ur Departure is Hsinchu");
                choice3.add("Taichung");
                choice3.add("Chiayi");
                choice3.add("Tainan");
                choice3.add("Kaohsiung");
                lv.setAdapter(choice4);
            }
            if (i == 3) {
                dep = 3;
                txv.setText("Ur Departure is Taichung");
                choice3.add("Chiayi");
                choice3.add("Tainan");
                choice3.add("Kaohsiung");
                lv.setAdapter(choice4);
            }
            if (i == 4) {
                dep = 4;
                txv.setText("Ur Departure is Chiayi");
                choice3.add("Tainan");
                choice3.add("Kaohsiung");
                lv.setAdapter(choice4);
            }
            if (i == 5) {
                dep = 5;
                txv.setText("Ur Departure is Tainan");
                choice3.add("Kaohsiung");
                lv.setAdapter(choice4);
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }


    // for listview
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        TextView txv2 = findViewById(R.id.tvShow2);
        TextView txv3 = findViewById(R.id.tvShow3);


        if (flag == 0) { // to North
            if(i==0) { //  from Taoyuan
                des=0;
                txv2.setText("Ur Destination is Taipei");
            }
            if(i==1){
                des=1;
                txv2.setText("Ur Destination is Taoyuan");
            }
            if(i==2){
                des=2;
                txv2.setText("Ur Destination is Hsinchu");
            }
            if(i==3){
                des=3;
                txv2.setText("Ur Destination is Taichung");
            }
            if(i==4){
                des=4;
                txv2.setText("Ur Destination is Chiayi");
            }
            if(i==5){
                des=5;
                txv2.setText("Ur Destination is Tainan");
            }
        }
        if(flag==1){
            if(i==0) { //  from Taoyuan
                des=1;
                txv2.setText("Ur Destination is Taoyuan");
            }
            if(i==1){
                des=2;
                txv2.setText("Ur Destination is Hsinchu");
            }
            if(i==2){
                des=3;
                txv2.setText("Ur Destination is Taichung");
            }
            if(i==3){
                des=4;
                txv2.setText("Ur Destination is Chiayi");
            }
            if(i==4){
                des=5;
                txv2.setText("Ur Destination is Chiayi");
            }
            if(i==5){
                des=6;
                txv2.setText("Ur Destination is Kaohsiung");
            }
        }

    if(Math.abs(des-dep)==1){
        txv3.setText("U should pay 160NT");
    }
    if(Math.abs(des-dep)==2){
        txv3.setText("U should pay 290NT");
    }
    if(Math.abs(des-dep)==3){
        txv3.setText("U should pay 700NT");
    }
    if(Math.abs(des-dep)==4){
        txv3.setText("U should pay 1080NT");
    }
    if(Math.abs(des-dep)==5){
        txv3.setText("U should pay 1350NT");
    }
    if(Math.abs(des-dep)==6){
        txv3.setText("U should pay 1490NT");
    }
    }
}